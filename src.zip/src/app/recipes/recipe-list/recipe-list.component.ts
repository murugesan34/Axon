import { Recipe } from './../recipe.module';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  public recipes: Recipe[] = [
    new Recipe("All are test mode", "This is first recipe product","https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/delish-191907-air-fryer-potatoes-0139-landscape-pf-1565021592.png?crop=0.668xw:1.00xh;0.175xw,0&resize=768:*"),
    new Recipe("All are test mode", "This is first recipe product","https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/delish-191907-air-fryer-potatoes-0139-landscape-pf-1565021592.png?crop=0.668xw:1.00xh;0.175xw,0&resize=768:*"),
    new Recipe("All are test mode", "This is first recipe product","https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/delish-191907-air-fryer-potatoes-0139-landscape-pf-1565021592.png?crop=0.668xw:1.00xh;0.175xw,0&resize=768:*")
  ]
  constructor() {
    console.log(this.recipes);
  }

  ngOnInit() {
  }

}
